/** Automatically generated file. DO NOT MODIFY */
package com.example.choisemorepictures;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}