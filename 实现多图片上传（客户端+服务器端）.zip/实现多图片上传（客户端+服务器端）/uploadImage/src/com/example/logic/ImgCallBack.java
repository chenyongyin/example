package com.example.logic;

import android.graphics.Bitmap;
import android.widget.ImageView;

public interface ImgCallBack {
	public void resultImgCall(ImageView imageView,Bitmap bitmap);
}
